/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const encode: (a: number, b: number, c: number) => void;
export const translateToBrailleFont: (a: number, b: number, c: number) => void;
export const translateToUnicode: (a: number, b: number, c: number) => void;
export const __wbindgen_add_to_stack_pointer: (a: number) => number;
export const __wbindgen_export: (a: number, b: number) => number;
export const __wbindgen_export2: (a: number, b: number, c: number, d: number) => number;
export const __wbindgen_export3: (a: number, b: number, c: number) => void;
